import React from 'react';
import '../App.css';

const Home = () => {
  return (
    <div>
      <p>
        Welcome to my pokemon site!
      </p>

      <p className="hometext">
         This site allows you to create Trainers and create pokemon parties for each trainer.
      </p>
    </div>
  );
};
export default Home;
