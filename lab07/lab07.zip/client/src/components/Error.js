import React from 'react'
import '../App.js'

const Error = () => {
    return (
        <div>
            <p>
                404 Error: Could not complete request.
            </p>
        </div>
    )
}

export default Error;